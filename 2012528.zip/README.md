# NLP-asm

## Installation

```bash
$ pip install -r requirements.txt
```

## Part 1

```bash
$ python part1.py
```

## Part 2: 

```bash
$ python part2.py
```